https://nvdemo2storageacct.blob.core.windows.net/images/_MG_0160.JPG
===
https://nvdemo2storageacct.blob.core.windows.net/images/_MG_0160.JPG?sp=r&st=2022-09-20T08:50:28Z&se=2022-09-21T16:50:28Z&spr=https&sv=2021-06-08&sr=b&sig=im4QeSvvA%2FFXB6IQkqVSJ76sluYYJAE63J%2BC8pCY%2FLM%3D